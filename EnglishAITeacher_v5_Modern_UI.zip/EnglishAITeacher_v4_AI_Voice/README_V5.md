# English AI Teacher v5

این نسخه رابط کاربری را به سبک اپ‌های مدرن آموزش زبان بازطراحی کرده است:
- صفحه Home با کارت‌های Speaking / Listening / Grammar / Lessons
- بخش Lessons با سه سطح Beginner / Intermediate / Advanced
- صفحه AI Conversation با دکمه میکروفون بزرگ
- صفحه Progress
- صفحه Profile و تنظیم SERVER_URL
- حفظ معماری مکالمه صوتی واقعی OpenAI Realtime از نسخه 4

## نکته مهم
برای مکالمه صوتی واقعی، در Profile آدرس HTTPS سروری را وارد کنید که `/realtime-token` را ارائه می‌دهد. کلید اصلی OpenAI نباید داخل APK قرار گیرد.
