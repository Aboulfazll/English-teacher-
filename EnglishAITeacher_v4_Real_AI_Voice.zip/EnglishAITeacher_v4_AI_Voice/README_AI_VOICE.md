# English AI Teacher v4 — Real AI Voice
This version adds a real-time AI voice teacher using OpenAI Realtime over WebRTC.
The Android app uses a secure short-lived client secret obtained from your backend.
The normal OpenAI API key stays on the server and is never embedded in the APK.
You must deploy the included server over HTTPS and set SERVER_URL in index.html.
