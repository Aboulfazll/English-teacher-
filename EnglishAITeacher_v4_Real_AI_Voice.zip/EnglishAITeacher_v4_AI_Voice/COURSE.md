# English AI Teacher v3 — Full Course
36 original lessons: 12 Beginner, 12 Intermediate, 12 Advanced.
Each lesson has vocabulary, grammar focus, lesson audio, listening practice and speaking practice.
This is original educational content and does not reproduce copyrighted Top Notch textbook/audio.
