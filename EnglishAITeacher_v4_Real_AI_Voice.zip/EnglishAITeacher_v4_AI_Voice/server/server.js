import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/realtime-token", async (req,res)=>{
  try{
    const r=await fetch("https://api.openai.com/v1/realtime/client_secrets",{
      method:"POST",
      headers:{
        "Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        session:{
          type:"realtime",
          model:"gpt-realtime-2.1",
          audio:{
            input:{turn_detection:{type:"semantic_vad",eagerness:"medium"},
                    transcription:{model:"gpt-4o-transcribe",language:"en"}},
            output:{voice:"marin"}
          }
        }
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json(data);
    res.json({value:data.value,expires_at:data.expires_at});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get("/health",(req,res)=>res.json({ok:true}));
app.listen(process.env.PORT||3000,()=>console.log("Realtime token server running"));
