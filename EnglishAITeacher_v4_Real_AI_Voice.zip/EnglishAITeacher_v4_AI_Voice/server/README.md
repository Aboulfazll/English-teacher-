# Secure Realtime backend
1. Install Node.js 20+.
2. Run: npm install
3. Set your server-side OpenAI API key:
   Windows PowerShell: $env:OPENAI_API_KEY="YOUR_KEY"
   macOS/Linux: export OPENAI_API_KEY="YOUR_KEY"
4. Run: npm start
5. Deploy this server over HTTPS.
6. In app/src/main/assets/index.html replace SERVER_URL with your HTTPS server URL.

Never put OPENAI_API_KEY inside the Android app. The backend creates a short-lived Realtime client secret for the phone.
